import axios from "axios";

export const Axios = axios.create({
  baseURL: "http://185.8.174.74:8080/",
});
