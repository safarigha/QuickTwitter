// define global schema for TS
// محتوای فایل شما
export {};
