//display tags in right side
import React from "react";

const TweetTags: React.FC = () => {
  return <div>Tweet Tags</div>;
};

export default TweetTags;
