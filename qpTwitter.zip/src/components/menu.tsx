//menu(left side)

import React from "react";

const Menu: React.FC = () => {
  // محتوای کامپوننت شما
  return <div>Menu</div>;
};

export default Menu;
